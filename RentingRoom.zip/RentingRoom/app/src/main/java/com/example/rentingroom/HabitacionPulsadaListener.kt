package com.example.rentingroom

interface HabitacionPulsadaListener {
    fun habitacionPulsada(habitacion: Habitaciones)

}