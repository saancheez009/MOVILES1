package com.example.rentingroom

data class Habitaciones (val numero:String, val nombre:String, val fecha:String){

}